import React from 'react';
import './NewsItem.css'; // Custom CSS for NewsItem

const NewsItem = ({ article }) => {
  return (
    <div className="col-md-4">
      <div className="card mb-4 shadow-sm">
        {/* <img src={article.urlToImage} className="card-img-top" alt="News" /> */}
        <div className="card-body">
          <h5 className="card-title">{article.title}</h5>
          <p className="card-text">{article.description}</p>
          <a href={article.url} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
            Read More
          </a>
        </div>
      </div>
    </div>
  );
};

export default NewsItem;
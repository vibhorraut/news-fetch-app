import React, { useEffect, useState } from 'react';
import axios from 'axios';
import NewsItem from './NewsItem';
import './NewsList.css'; // Custom CSS for NewsList

const NewsList = () => {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    const fetchNews = async () => {
      const response = await axios.get('https://newsapi.org/v2/top-headlines?country=in&apiKey=4ff009b858e043fcb08bba14871abda8');
    //  const response = await axios.get('https://api.currentsapi.services/v1/latest-news?country=in&language=en&apiKey=x_bF1ckooTGHEta2rIIAcDM3f7j6PNnK-2DsFKYjjaPPv4cW');
    // const response = await axios.get('https://gnews.io/api/v4/top-headlines?country=in&lang=en&token=27854024455ed3d92767fe9babf62119');


    setArticles(response.data.articles);
    };
    fetchNews();
  }, []);

  return (
    <div className="container my-5">
      <div className="row">
        {articles.map((article, index) => (
          <NewsItem key={index} article={article} />
        ))}
      </div>
    </div>
  );
};

export default NewsList;
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import NewsList from './components/NewsList';

function App() {
  return (
    <div>
      <header className="bg-primary text-white text-center py-5">
        <h1>Latest News</h1>
      </header>
      <NewsList />
    </div>
  );
}

export default App;